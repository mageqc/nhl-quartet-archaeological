# Calculateurs pour les cotes et gestion de portefeuille
